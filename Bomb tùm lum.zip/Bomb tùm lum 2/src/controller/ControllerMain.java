package controller;

public interface ControllerMain {
	public void displayGame();
}
