package model;

public interface OrientableInterface {
	public void changeOrient(Object object, int orient);
}
