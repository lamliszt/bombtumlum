package model;

import java.awt.Graphics2D;

public interface DrawableInterface {
	public void draw(Object object, Graphics2D g2d);
}
